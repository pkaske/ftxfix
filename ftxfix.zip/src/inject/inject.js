chrome.extension.sendMessage({}, function(response) {
	var readyStateCheckInterval = setInterval(function() {
	if (document.readyState === "complete") {
		clearInterval(readyStateCheckInterval);
		document.querySelectorAll('header')[1].id = '___symbolSelector';
	}
	}, 10);
});